FASHION AFFILIATE STUDIO — ANDROID APK PROJECT

This is the Android source project. It is NOT an APK yet.
It includes a GitHub Actions workflow to build a debug APK in the cloud.

BUILD IN THE CLOUD (can be initiated from Android browser):
1. Sign in to GitHub and create a new repository.
2. Upload the CONTENTS of this folder to the repository root. Keep the hidden
   .github/workflows/build-apk.yml file in its exact location.
3. Commit to the main branch. The workflow starts automatically.
   Or open GitHub > Actions > Build Android APK > Run workflow.
4. Wait for the workflow to finish successfully.
5. Open the workflow run, scroll to Artifacts, and download
   FashionAffiliateStudio-debug-apk.
6. Extract the downloaded artifact ZIP. It contains app-debug.apk.
7. Tap app-debug.apk and follow Android's install prompt. If asked, allow
   "Install unknown apps" for the browser or file manager you used.

BUILD LOCALLY:
- Android Studio
- JDK 17
- Android SDK Platform 35
- Gradle 8.9
Run: gradle assembleDebug
Output: app/build/outputs/apk/debug/app-debug.apk

IMPORTANT:
- This project has not been compiled or device-tested in this environment.
- Debug APK is for personal testing, not Play Store release.
- The app creates prompts and manages local workflow. It does not itself
  render AI images/videos or connect to TikTok.
